package slides;

public class MexendoComBooleanIfeElse {

	public static void main(String[] args) {
		double nota = 4.0;
		if(nota >= 7.0){
			System.out.println("Estou Feliz :D");
		}else{
			System.out.println("Estou Triste :'(");
		}

	}

}
