package slides;

public class MexendoComBoolean2 {

	public static void main(String[] args) {
		boolean pagueiMinhasContas = false, fuiPassear = true;
		boolean estouFeliz = fuiPassear && pagueiMinhasContas;
		System.out.println(estouFeliz);

	}

}
