package slides;

public class CalculadoraComVari�veis {

	public static void main(String[] args) {
		//Imprimindo mensagem de Boas Vindas
		System.out.println("Bem Vindo(a) a Calculadora de M�dias!!");
		double nota1 = 9.0, nota2 = 5.8, nota3 = 6.3, media;
		//Somando as tr�s notas e imprimindo a respectiva m�dia
		media = ((nota1 + nota2 + nota3) /3);
		System.out.println("Nota1: 9.0    Nota2: 5.8   Nota3: 6.3");
		System.out.println("Media: " + media);

	}

}
