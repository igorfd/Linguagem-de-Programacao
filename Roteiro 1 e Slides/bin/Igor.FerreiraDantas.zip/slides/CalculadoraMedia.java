package slides;

public class CalculadoraMedia {

	public static void main(String[] args) {
		//Imprimindo mensagem de Boas Vindas
		System.out.println("Bem vindo(a) a Calculadora de M�didas!");
		System.out.println("(9.2 + 7.2 + 4.9 + 9.0)/4" + (9.2 + 7.2 + 4.9 + 9.0)/4);

	}

}
