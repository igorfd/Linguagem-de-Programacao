package slides;

public class MexendoComBoolean {

	public static void main(String[] args) {
		boolean pagueiMinhasContas = true, fuiPassear = true;
		boolean estouFeliz = fuiPassear || pagueiMinhasContas;
		System.out.println(estouFeliz);

	}

}
