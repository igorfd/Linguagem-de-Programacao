package slides;

public class MexendoComBooleanIfeElse2 {

	public static void main(String[] args) {
		double nota = 0;
		if(nota >= 7.0 && nota <= 10.0){
			System.out.println("Estou feliz, fui aprovado! ");
		}else if(nota > 4.0 && nota < 7.0){
			System.out.println("Vixe, Estou na final! ");
		}else if(nota >= 0){
			System.out.println("Estou triste, fui reprovado!");
		}else{
			System.out.println("Nota Inv�lida!");
		}
		
		
			
			
			

	}

}
