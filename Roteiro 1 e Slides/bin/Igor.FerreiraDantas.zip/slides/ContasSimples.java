package slides;

public class ContasSimples {

	public static void main(String[] args) {
		System.out.println("Oi Mundo!");
		System.out.println("Vamos fazer umas contas simples?");
		System.out.println("122+12= "+ (122+12));//Soma
		System.out.println("50-12 = "+ (50-12)); //Subtra��o
		System.out.println("87*3 = " + (87*3)); //Multipla��o
		System.out.println("78/12 = " + (78/12)); //Divis�o

	}

}
