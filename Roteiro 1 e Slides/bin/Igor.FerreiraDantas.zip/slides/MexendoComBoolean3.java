package slides;

public class MexendoComBoolean3 {

	public static void main(String[] args) {
		double nota = 4.0;
		boolean estouFeliz = nota >= 7.0;
		System.out.println(estouFeliz);
	}

}
